package NonSpiffy;

use Filter4; # Filter4 /is/ Spiffy

1;
